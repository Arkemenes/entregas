/**
 *	20-UART 
 * Prof. Rafael Corsi
 *
 *    (e.g., HyperTerminal on Microsoft Windows) with these settings:
 *   - 115200 bauds
 *   - 8 bits of data
 *   - No parity
 *   - 1 stop bit
 *   - No flow control
 */

#include "asf.h"
#include "conf_board.h"
#include "conf_clock.h"

/************************************************************************/
/* Configura��es                                                        */
/************************************************************************/

#define STRING_EOL    "\r"
#define STRING_VERSAO "-- "BOARD_NAME" --\r\n" \
					  "-- Compiled: "__DATE__" "__TIME__" --"STRING_EOL

#define CONF_UART_BAUDRATE 115200		
#define CONF_UART          CONSOLE_UART

/** 
 * LEDs
 */ 

#define time			100
#define PIN_ECHO		21
#define PIN_TRIGGER		22

/** 
 * Defini��o dos ports
 * Ports referentes a cada pino
 */

#define PORT_TRIGGER		PIOA


/**
 * Define os IDs dos perif�ricos associados aos pinos
 */

#define ID_SENSOR		ID_PIOA

/**
 *	Define as masks utilziadas
 */

#define MASK_TRIGGER	(1u << PIN_TRIGGER)
#define MASK_ECHO		(1u << PIN_ECHO)
	uint32_t  distancia; 

/*
* capture mode
*/
#define TC_CAPTURE_TIMER_SELECTION TC_CMR_TCCLKS_TIMER_CLOCK5

/** Capture status*/
static uint32_t gs_ul_captured_pulses;
static uint32_t gs_ul_captured_ra;
static uint32_t gs_ul_captured_rb;

/**
 * \brief Configure TC TC_CHANNEL_CAPTURE in capture operating mode.
 */
//! [tc_capture_init]
static void tc_capture_initialize(void)
{
	/* Configure the PMC to enable the TC module */
	sysclk_enable_peripheral_clock(ID_TC_CAPTURE);

	/* Init TC to capture mode. */
	tc_init(TC, TC_CHANNEL_CAPTURE,
			TC_CAPTURE_TIMER_SELECTION /* Clock Selection */
			| TC_CMR_LDRA_RISING /* RA Loading: rising edge of TIOA */
			| TC_CMR_LDRB_FALLING /* RB Loading: falling edge of TIOA */
			| TC_CMR_ABETRG /* External Trigger: TIOA */
			| TC_CMR_ETRGEDG_FALLING /* External Trigger Edge: Falling edge */
	);
}
//! [tc_capture_init]

/**
 * \brief Interrupt handler for the TC TC_CHANNEL_CAPTURE
 */
//! [tc_capture_irq_handler_start]
void TC_Handler(void)
{
	if ((tc_get_status(TC, TC_CHANNEL_CAPTURE) & TC_SR_LDRBS) == TC_SR_LDRBS) {
		gs_ul_captured_pulses++;
		gs_ul_captured_ra = tc_read_ra(TC, TC_CHANNEL_CAPTURE);
		gs_ul_captured_rb = tc_read_rb(TC, TC_CHANNEL_CAPTURE);
		printf("ra: %d, rb: %d : dT: %d\n", gs_ul_captured_ra,gs_ul_captured_rb, gs_ul_captured_rb-gs_ul_captured_ra);
		
		//distancia = conta(gs_ul_captured_rb, gs_ul_captured_ra);
		distancia = gs_ul_captured_rb-gs_ul_captured_ra;
	}
}

/************************************************************************/
/* Configura UART                                                       */
/************************************************************************/


void config_uart(void){
	
	/* configura pinos */
	gpio_configure_group(PINS_UART0_PIO, PINS_UART0, PINS_UART0_FLAGS);
	
	/* ativa clock */
	sysclk_enable_peripheral_clock(CONSOLE_UART_ID);

	/* Configura��o UART */
	const usart_serial_options_t uart_serial_options = {
		.baudrate   = CONF_UART_BAUDRATE,
		.paritytype = UART_MR_PAR_NO,
		.stopbits   = 0
	};
	
	stdio_serial_init((Usart *)CONF_UART, &uart_serial_options);
}



/************************************************************************/
/* Main                                                                 */
/************************************************************************/
int main(void)
{
	uint8_t uc_key;

	/* Initialize the system */
	sysclk_init();
	board_init();

	/* Configure LED 1 */
	pmc_enable_periph_clk(ID_LED_BLUE);
	pio_set_output(PORT_LED_BLUE  , MASK_LED_BLUE	,1,0,0);
	pmc_enable_periph_clk(ID_LED_BLUE);
	pio_set_output(PORT_LED_GREEN  , MASK_LED_GREEN	,1,0,0);
	pmc_enable_periph_clk(ID_LED_BLUE);
	pio_set_output(PORT_LED_RED  , MASK_LED_RED	,1,0,1);	
		
	/* Initialize debug console */
	config_uart();
	
	/** 
	*  Desabilitando o WathDog do uP
	*/
	WDT->WDT_MR = WDT_MR_WDDIS;
		
	/**
	* Ativa clock nos perif�ricos
	*/
	pmc_enable_periph_clk(ID_LED_BLUE);
	pmc_enable_periph_clk(ID_LED_GREEN);
	pmc_enable_periph_clk(ID_LED_RED);
	pmc_enable_periph_clk(ID_SENSOR);
	
	/**
	* Configura ECHO e trigger como sa�da e entrada
	*/
	pio_set_output(PORT_TRIGGER  , MASK_TRIGGER	,1,0,0);


	/************************************************************************/
	/*capture mode                                  */
	/************************************************************************/
	tc_capture_initialize();
	
	ioport_set_pin_mode(PIN_TC_CAPTURE, PIN_TC_CAPTURE_MUX);
	/** Disable I/O to enable peripheral mode) */
	ioport_disable_pin(PIN_TC_CAPTURE);
	
	/* Configure TC TC_CHANNEL_WAVEFORM as waveform operating mode */
	printf("Configure TC%d channel %d as waveform operating mode \n\r",
			TC_PERIPHERAL, TC_CHANNEL_WAVEFORM);
				
	/** Configure TC interrupts for TC TC_CHANNEL_CAPTURE only */
	NVIC_DisableIRQ(TC_IRQn);
	NVIC_ClearPendingIRQ(TC_IRQn);
	NVIC_SetPriority(TC_IRQn, 0);
	NVIC_EnableIRQ(TC_IRQn);

	tc_enable_interrupt(TC, TC_CHANNEL_CAPTURE, TC_IER_LDRBS);
	tc_start(TC, TC_CHANNEL_CAPTURE);

	while (1) {
				
			pio_clear(PORT_TRIGGER, MASK_TRIGGER);
			delay_ms(750);
			pio_set(PORT_TRIGGER, MASK_TRIGGER);
			delay_ms(70);
	
	}
}
